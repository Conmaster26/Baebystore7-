import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useCart } from "@/contexts/CartContext";
import { Trash2, ShoppingCart, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

/**
 * Baeby Cart Page - Design Philosophy: Modern Minimalism with Warmth
 * Displays cart items, allows quantity adjustments, and provides checkout options
 */

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
          <div className="container flex items-center justify-between py-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">B</span>
              </div>
              <h1 className="text-2xl font-bold text-foreground">Baeby</h1>
            </div>
          </div>
        </nav>

        {/* Empty Cart */}
        <div className="container flex flex-col items-center justify-center min-h-[60vh] space-y-8">
          <ShoppingCart className="w-24 h-24 text-muted-foreground" />
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-foreground">Your Cart is Empty</h2>
            <p className="text-lg text-muted-foreground">
              Explore our curated collection and add some beautiful baby clothes to your cart.
            </p>
          </div>
          <Link href="/">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">B</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Baeby</h1>
          </div>
        </div>
      </nav>

      {/* Cart Content */}
      <div className="container py-12">
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Shop
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-3xl font-bold text-foreground">Shopping Cart</h2>

            {items.map((item) => (
              <Card key={item.id} className="p-6 bg-card border-border flex gap-6">
                <div className="w-24 h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">{item.name}</h3>
                    <p className="text-primary font-semibold">R{item.price}</p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center border border-border rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-3 py-2 text-foreground hover:bg-muted transition-colors"
                      >
                        −
                      </button>
                      <span className="px-4 py-2 text-foreground">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-3 py-2 text-foreground hover:bg-muted transition-colors"
                      >
                        +
                      </button>
                    </div>

                    <button
                      onClick={() => removeItem(item.id)}
                      className="ml-auto text-destructive hover:bg-destructive/10 p-2 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    Subtotal: R{(item.price * item.quantity).toLocaleString()}
                  </p>
                </div>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="p-8 bg-card border-border sticky top-24 space-y-6">
              <h3 className="text-2xl font-bold text-foreground">Order Summary</h3>

              <div className="space-y-4 border-t border-b border-border py-6">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>R{total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span>R0 (10-20 days)</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Tax (VAT)</span>
                  <span>Calculated at checkout</span>
                </div>
              </div>

              <div className="flex justify-between text-xl font-bold text-foreground">
                <span>Total</span>
                <span className="text-primary">R{total.toLocaleString()}</span>
              </div>

              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg py-6">
                Proceed to Checkout
              </Button>

              <Button
                variant="outline"
                className="w-full border-primary text-primary hover:bg-primary/10 rounded-lg"
                onClick={clearCart}
              >
                Clear Cart
              </Button>

              <div className="p-4 bg-primary/10 rounded-lg space-y-2">
                <p className="text-sm font-semibold text-foreground">📦 Shipping Info</p>
                <p className="text-sm text-muted-foreground">
                  Delivery in 10-20 working days via Buffalo International Logistics. Full tracking provided.
                </p>
              </div>

              <div className="p-4 bg-primary/10 rounded-lg space-y-2">
                <p className="text-sm font-semibold text-foreground">💬 Need Help?</p>
                <p className="text-sm text-muted-foreground">
                  Contact us via WhatsApp: <strong>066 564 7535</strong>
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
