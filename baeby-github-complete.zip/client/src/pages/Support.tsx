import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronDown, Mail, Phone, MapPin } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

/**
 * Baeby Support & FAQ Page - Design Philosophy: Modern Minimalism with Warmth
 * Provides comprehensive information about shipping, returns, and customer support
 */

interface FAQItem {
  id: number;
  question: string;
  answer: string;
}

const FAQ_ITEMS: FAQItem[] = [
  {
    id: 1,
    question: "How long does delivery take?",
    answer:
      "We ship all orders within 1-2 business days. Delivery typically takes 10-20 working days to South Africa via Buffalo International Logistics. You'll receive a tracking number as soon as your order ships.",
  },
  {
    id: 2,
    question: "What payment methods do you accept?",
    answer:
      "We accept all major payment methods including EFT transfers, credit cards (Visa, Mastercard), and mobile payments (Ozow, PayFast). All transactions are secure and encrypted.",
  },
  {
    id: 3,
    question: "Can I return or exchange items?",
    answer:
      "Yes! We offer hassle-free returns and exchanges within 30 days of purchase. Items must be unused and in original packaging. Contact our support team to initiate a return.",
  },
  {
    id: 4,
    question: "Are the products safe for babies?",
    answer:
      "Absolutely. All Baeby products meet international safety standards and are made from high-quality, baby-safe materials. We prioritize your baby's comfort and safety above all else.",
  },
  {
    id: 5,
    question: "Do you offer bulk discounts?",
    answer:
      "Yes! For bulk orders (10+ items), please contact our support team at support@baeby.co.za or WhatsApp 066 564 7535 for special pricing.",
  },
  {
    id: 6,
    question: "What's your return policy?",
    answer:
      "We offer a 30-day money-back guarantee. If you're not satisfied with your purchase, simply contact us with your order number and reason for return. We'll arrange a refund or exchange.",
  },
  {
    id: 7,
    question: "How do I track my order?",
    answer:
      "Once your order ships, you'll receive an email with a Buffalo Logistics tracking number. You can use this number to track your package in real-time on their website.",
  },
  {
    id: 8,
    question: "Do you ship internationally?",
    answer:
      "Currently, we ship only to South Africa. For international inquiries, please contact our support team at support@baeby.co.za.",
  },
];

export default function SupportPage() {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const toggleExpanded = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">B</span>
              </div>
              <h1 className="text-2xl font-bold text-foreground">Baeby</h1>
            </div>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-background py-12">
        <div className="container text-center space-y-4">
          <h1 className="text-4xl font-bold text-foreground">Help & Support</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We're here to help! Find answers to common questions or reach out to our support team.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-card/50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-8 bg-background border-border text-center hover:shadow-lg transition-shadow">
              <Phone className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-2">WhatsApp Support</h3>
              <p className="text-muted-foreground mb-4">Chat with us directly</p>
              <a href="https://wa.me/27665647535" target="_blank" rel="noopener noreferrer">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  066 564 7535
                </Button>
              </a>
            </Card>

            <Card className="p-8 bg-background border-border text-center hover:shadow-lg transition-shadow">
              <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-2">Email Support</h3>
              <p className="text-muted-foreground mb-4">We respond within 24 hours</p>
              <a href="mailto:support@baeby.co.za">
                <Button variant="outline" className="border-primary text-primary hover:bg-primary/10">
                  support@baeby.co.za
                </Button>
              </a>
            </Card>

            <Card className="p-8 bg-background border-border text-center hover:shadow-lg transition-shadow">
              <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-2">Location</h3>
              <p className="text-muted-foreground mb-4">Polokwane, Limpopo</p>
              <p className="text-sm text-muted-foreground">South Africa</p>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-background">
        <div className="container max-w-3xl">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-4xl font-bold text-foreground">Frequently Asked Questions</h2>
            <p className="text-lg text-muted-foreground">
              Find answers to the most common questions about Baeby.
            </p>
          </div>

          <div className="space-y-4">
            {FAQ_ITEMS.map((item) => (
              <Card
                key={item.id}
                className="bg-card border-border overflow-hidden hover:shadow-md transition-shadow"
              >
                <button
                  onClick={() => toggleExpanded(item.id)}
                  className="w-full p-6 flex items-center justify-between text-left hover:bg-muted/50 transition-colors"
                >
                  <h3 className="text-lg font-semibold text-foreground pr-4">{item.question}</h3>
                  <ChevronDown
                    className={`w-5 h-5 text-primary flex-shrink-0 transition-transform ${
                      expandedId === item.id ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {expandedId === item.id && (
                  <div className="px-6 pb-6 border-t border-border pt-4">
                    <p className="text-muted-foreground leading-relaxed">{item.answer}</p>
                  </div>
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Shipping Information */}
      <section className="py-16 bg-card/50">
        <div className="container max-w-3xl space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-foreground">Shipping & Delivery</h2>
            <p className="text-lg text-muted-foreground">
              Everything you need to know about our shipping process.
            </p>
          </div>

          <div className="space-y-6">
            <Card className="p-8 bg-background border-border">
              <h3 className="text-2xl font-bold text-foreground mb-4">📦 Delivery Timeline</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex gap-3">
                  <span className="text-primary font-bold">1-2 days:</span>
                  <span>Order processing and preparation</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">10-20 days:</span>
                  <span>Shipping to South Africa via Buffalo Logistics</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">1-2 days:</span>
                  <span>Local delivery to your address</span>
                </li>
              </ul>
            </Card>

            <Card className="p-8 bg-background border-border">
              <h3 className="text-2xl font-bold text-foreground mb-4">🚚 Shipping Costs</h3>
              <p className="text-muted-foreground mb-4">
                We offer FREE shipping on all orders within South Africa! International shipping is available upon request.
              </p>
              <p className="text-sm text-muted-foreground italic">
                Note: Customs duties and VAT may apply to international orders and will be calculated at checkout.
              </p>
            </Card>

            <Card className="p-8 bg-background border-border">
              <h3 className="text-2xl font-bold text-foreground mb-4">✅ Order Tracking</h3>
              <p className="text-muted-foreground mb-4">
                Once your order ships, you'll receive an email with a tracking number from Buffalo Logistics. You can track your package in real-time on their website.
              </p>
              <p className="text-sm text-muted-foreground">
                Lost or damaged packages are covered by our insurance. Contact us immediately if you experience any issues.
              </p>
            </Card>

            <Card className="p-8 bg-background border-border">
              <h3 className="text-2xl font-bold text-foreground mb-4">🔄 Returns & Exchanges</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex gap-3">
                  <span className="text-primary font-bold">30 days:</span>
                  <span>Return window from purchase date</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">Condition:</span>
                  <span>Items must be unused and in original packaging</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">Process:</span>
                  <span>Contact support with your order number and reason</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-primary font-bold">Refund:</span>
                  <span>Full refund or exchange within 5-7 business days</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary to-primary/80">
        <div className="container text-center space-y-8">
          <h2 className="text-4xl font-bold text-primary-foreground">Still Have Questions?</h2>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Our friendly support team is here to help. Reach out via WhatsApp, email, or phone.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://wa.me/27665647535" target="_blank" rel="noopener noreferrer">
              <Button className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 rounded-lg">
                Chat on WhatsApp
              </Button>
            </a>
            <a href="mailto:support@baeby.co.za">
              <Button variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 rounded-lg">
                Send Email
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-primary-foreground py-12">
        <div className="container text-center text-sm text-primary-foreground/60">
          <p>&copy; 2026 Baeby. All rights reserved. Powered by Katlego Madiba Strategic Consulting.</p>
        </div>
      </footer>
    </div>
  );
}
