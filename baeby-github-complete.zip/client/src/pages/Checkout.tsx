import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ShoppingCart, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface CartItem {
  productId: string;
  productName: string;
  productPrice: number;
  quantity: number;
}

const SAMPLE_PRODUCTS: CartItem[] = [
  {
    productId: "temu-001",
    productName: "Soft Sage Onesie",
    productPrice: 29900, // R299 in cents
    quantity: 1,
  },
  {
    productId: "temu-002",
    productName: "Cream Floral Romper",
    productPrice: 34900,
    quantity: 1,
  },
];

export default function Checkout() {
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>(SAMPLE_PRODUCTS);
  const [isLoading, setIsLoading] = useState(false);

  // Customer info
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerFirstName, setCustomerFirstName] = useState("");
  const [customerLastName, setCustomerLastName] = useState("");

  // Delivery info
  const [deliveryFirstName, setDeliveryFirstName] = useState("");
  const [deliveryLastName, setDeliveryLastName] = useState("");
  const [deliveryEmail, setDeliveryEmail] = useState("");
  const [deliveryPhone, setDeliveryPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryCity, setDeliveryCity] = useState("");
  const [deliveryProvince, setDeliveryProvince] = useState("");
  const [deliveryPostalCode, setDeliveryPostalCode] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"payfast" | "yoco">(
    "payfast"
  );

  // Calculate totals
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.productPrice * item.quantity,
    0
  );
  const profitMargin = 15000; // R150 in cents
  const tax = Math.round((subtotal + profitMargin) * 0.15);
  const totalAmount = subtotal + profitMargin + tax;

  const handleRemoveItem = (productId: string) => {
    setCartItems(cartItems.filter((item) => item.productId !== productId));
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCartItems(
      cartItems.map((item) =>
        item.productId === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleCreateOrder = async () => {
    if (!customerEmail || !customerPhone || !deliveryAddress) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (cartItems.length === 0) {
      toast.error("Your cart is empty");
      return;
    }

    setIsLoading(true);

    try {
      // Call the order creation API
      const response = await fetch("/api/trpc/orders.createOrder", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerEmail,
          customerPhone,
          customerFirstName,
          customerLastName,
          deliveryFirstName,
          deliveryLastName,
          deliveryEmail,
          deliveryPhone,
          deliveryAddress,
          deliveryCity,
          deliveryProvince,
          deliveryPostalCode,
          items: cartItems,
          paymentMethod,
        }),
      });

      const data = await response.json();

      if (data.result?.data?.success) {
        toast.success(`Order created! Order #${data.result.data.orderNumber}`);
        // Redirect to payment page
        setLocation(
          `/payment?orderId=${data.result.data.orderId}&orderNumber=${data.result.data.orderNumber}`
        );
      } else {
        toast.error(data.result?.error?.message || "Failed to create order");
      }
    } catch (error) {
      console.error("Order creation error:", error);
      toast.error("Failed to create order. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => setLocation("/")}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-foreground">Checkout</h1>
        </div>
      </div>

      <div className="container py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Cart Items */}
          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-bold text-foreground">Order Summary</h2>
            {cartItems.map((item) => (
              <div
                key={item.productId}
                className="flex items-center justify-between pb-4 border-b border-border last:border-0"
              >
                <div className="flex-1">
                  <p className="font-semibold text-foreground">
                    {item.productName}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    R{(item.productPrice / 100).toFixed(2)} each
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) =>
                      handleUpdateQuantity(
                        item.productId,
                        parseInt(e.target.value) || 1
                      )
                    }
                    className="w-12 px-2 py-1 border border-border rounded text-center"
                  />
                  <p className="w-20 text-right font-semibold text-foreground">
                    R{((item.productPrice * item.quantity) / 100).toFixed(2)}
                  </p>
                  <button
                    onClick={() => handleRemoveItem(item.productId)}
                    className="text-red-500 hover:text-red-600 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </Card>

          {/* Customer Information */}
          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-bold text-foreground">
              Your Information
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={customerFirstName}
                  onChange={(e) => setCustomerFirstName(e.target.value)}
                  placeholder="John"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={customerLastName}
                  onChange={(e) => setCustomerLastName(e.target.value)}
                  placeholder="Doe"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0712345678"
                />
              </div>
            </div>
          </Card>

          {/* Delivery Information */}
          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-bold text-foreground">
              Delivery Address
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="deliveryFirstName">First Name *</Label>
                <Input
                  id="deliveryFirstName"
                  value={deliveryFirstName}
                  onChange={(e) => setDeliveryFirstName(e.target.value)}
                  placeholder="John"
                />
              </div>
              <div>
                <Label htmlFor="deliveryLastName">Last Name *</Label>
                <Input
                  id="deliveryLastName"
                  value={deliveryLastName}
                  onChange={(e) => setDeliveryLastName(e.target.value)}
                  placeholder="Doe"
                />
              </div>
              <div className="col-span-2">
                <Label htmlFor="address">Address *</Label>
                <Textarea
                  id="address"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="123 Main Street, Apartment 4B"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={deliveryCity}
                  onChange={(e) => setDeliveryCity(e.target.value)}
                  placeholder="Polokwane"
                />
              </div>
              <div>
                <Label htmlFor="province">Province *</Label>
                <Input
                  id="province"
                  value={deliveryProvince}
                  onChange={(e) => setDeliveryProvince(e.target.value)}
                  placeholder="Limpopo"
                />
              </div>
              <div>
                <Label htmlFor="postalCode">Postal Code *</Label>
                <Input
                  id="postalCode"
                  value={deliveryPostalCode}
                  onChange={(e) => setDeliveryPostalCode(e.target.value)}
                  placeholder="0700"
                />
              </div>
              <div>
                <Label htmlFor="deliveryEmail">Email *</Label>
                <Input
                  id="deliveryEmail"
                  type="email"
                  value={deliveryEmail}
                  onChange={(e) => setDeliveryEmail(e.target.value)}
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <Label htmlFor="deliveryPhone">Phone *</Label>
                <Input
                  id="deliveryPhone"
                  value={deliveryPhone}
                  onChange={(e) => setDeliveryPhone(e.target.value)}
                  placeholder="0712345678"
                />
              </div>
            </div>
          </Card>

          {/* Payment Method */}
          <Card className="p-6 space-y-4">
            <h2 className="text-xl font-bold text-foreground">
              Payment Method
            </h2>
            <div className="space-y-3">
              <label className="flex items-center gap-3 p-3 border border-border rounded-lg cursor-pointer hover:bg-card">
                <input
                  type="radio"
                  name="payment"
                  value="payfast"
                  checked={paymentMethod === "payfast"}
                  onChange={(e) =>
                    setPaymentMethod(e.target.value as "payfast" | "yoco")
                  }
                />
                <div>
                  <p className="font-semibold text-foreground">PayFast</p>
                  <p className="text-sm text-muted-foreground">
                    Credit/Debit Card, EFT
                  </p>
                </div>
              </label>
              <label className="flex items-center gap-3 p-3 border border-border rounded-lg cursor-pointer hover:bg-card">
                <input
                  type="radio"
                  name="payment"
                  value="yoco"
                  checked={paymentMethod === "yoco"}
                  onChange={(e) =>
                    setPaymentMethod(e.target.value as "payfast" | "yoco")
                  }
                />
                <div>
                  <p className="font-semibold text-foreground">Yoco</p>
                  <p className="text-sm text-muted-foreground">
                    Cards & Mobile Money
                  </p>
                </div>
              </label>
            </div>
          </Card>
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-24 space-y-6">
            <h2 className="text-xl font-bold text-foreground">Order Total</h2>

            <div className="space-y-3 pb-6 border-b border-border">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-semibold text-foreground">
                  R{(subtotal / 100).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Profit Margin</span>
                <span className="font-semibold text-foreground">
                  R{(profitMargin / 100).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tax (15%)</span>
                <span className="font-semibold text-foreground">
                  R{(tax / 100).toFixed(2)}
                </span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-lg font-bold text-foreground">Total</span>
              <span className="text-2xl font-bold text-primary">
                R{(totalAmount / 100).toFixed(2)}
              </span>
            </div>

            <Button
              onClick={handleCreateOrder}
              disabled={isLoading || cartItems.length === 0}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg h-12"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Proceed to Payment
                </>
              )}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              Delivery in 10-20 working days via Buffalo International Logistics
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
