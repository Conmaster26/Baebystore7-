import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle, AlertCircle, Copy } from "lucide-react";
import { trpc } from "@/lib/trpc";

type PaymentStep = "instructions" | "details" | "processing" | "success" | "error";

export default function Payment() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<PaymentStep>("instructions");
  const [orderId, setOrderId] = useState<number | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);
  const [totalAmount, setTotalAmount] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Form state
  const [cardholderName, setCardholderName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryMonth, setExpiryMonth] = useState("");
  const [expiryYear, setExpiryYear] = useState("");
  const [cvv, setCvv] = useState("");

  // Get query parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("orderId");
    const number = params.get("orderNumber");
    const amount = params.get("amount");

    if (id && number && amount) {
      setOrderId(parseInt(id));
      setOrderNumber(number);
      setTotalAmount(parseFloat(amount));
    } else {
      setErrorMessage("Invalid order information");
      setStep("error");
    }
  }, []);

  // Fetch payment instructions
  const { data: instructions } = trpc.payment.getPaymentInstructions.useQuery();

  // Process payment mutation
  const processBankTransfer = trpc.payment.processBankTransfer.useMutation();

  const handleSubmitPayment = async () => {
    if (!orderId || !totalAmount) return;

    // Validate form
    if (!cardholderName || !cardNumber || !expiryMonth || !expiryYear || !cvv) {
      setErrorMessage("Please fill in all payment details");
      return;
    }

    setStep("processing");

    try {
      await processBankTransfer.mutateAsync({
        orderId,
        cardholderName,
        cardNumber: cardNumber.slice(-4),
        expiryMonth,
        expiryYear,
        cvv,
        amount: totalAmount,
      });

      setStep("success");
    } catch (error) {
      console.error("Payment error:", error);
      setErrorMessage(
        error instanceof Error ? error.message : "Payment processing failed"
      );
      setStep("error");
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-4">
        {/* Payment Instructions */}
        {step === "instructions" && (
          <Card className="p-8 space-y-6">
            <div className="text-center space-y-2">
              <AlertCircle className="w-12 h-12 text-blue-600 mx-auto" />
              <h1 className="text-2xl font-bold text-foreground">
                Bank Transfer Payment
              </h1>
              <p className="text-muted-foreground">
                Order #{orderNumber}
              </p>
            </div>

            {instructions && (
              <div className="space-y-4 bg-blue-50 p-6 rounded-lg border border-blue-200">
                <h2 className="font-bold text-foreground">Payment Details</h2>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Bank:</span>
                    <span className="font-semibold text-foreground">
                      {instructions.bankName}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Account Holder:</span>
                    <span className="font-semibold text-foreground">
                      {instructions.accountHolder}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Account Number:</span>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-foreground">
                        {instructions.accountNumber}
                      </span>
                      <button
                        onClick={() =>
                          copyToClipboard(instructions.accountNumber)
                        }
                        className="p-1 hover:bg-blue-100 rounded"
                      >
                        <Copy className="w-4 h-4 text-blue-600" />
                      </button>
                    </div>
                  </div>
                  {copied && (
                    <p className="text-xs text-green-600">Copied!</p>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Reference:</span>
                    <span className="font-semibold text-foreground">
                      {orderNumber}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-bold text-green-600 text-lg">
                      R{totalAmount?.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="bg-white p-3 rounded border border-blue-200 text-xs text-muted-foreground">
                  <p className="font-semibold text-foreground mb-2">
                    Instructions:
                  </p>
                  <ul className="space-y-1 list-disc list-inside">
                    {instructions.instructions.map((instruction, i) => (
                      <li key={i}>{instruction}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <Button
                onClick={() => setStep("details")}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12"
              >
                Continue to Payment
              </Button>
              <Button
                onClick={() => setLocation("/checkout")}
                variant="outline"
                className="w-full"
              >
                Back to Checkout
              </Button>
            </div>
          </Card>
        )}

        {/* Payment Details Form */}
        {step === "details" && (
          <Card className="p-8 space-y-6">
            <div className="text-center space-y-2">
              <h1 className="text-2xl font-bold text-foreground">
                Enter Payment Details
              </h1>
              <p className="text-muted-foreground">
                Amount: R{totalAmount?.toFixed(2)}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Cardholder Name
                </label>
                <input
                  type="text"
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Card Number (Last 4 Digits)
                </label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) =>
                    setCardNumber(e.target.value.replace(/\D/g, "").slice(-4))
                  }
                  placeholder="1234"
                  maxLength={4}
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Month
                  </label>
                  <input
                    type="text"
                    value={expiryMonth}
                    onChange={(e) =>
                      setExpiryMonth(e.target.value.replace(/\D/g, "").slice(0, 2))
                    }
                    placeholder="MM"
                    maxLength={2}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Year
                  </label>
                  <input
                    type="text"
                    value={expiryYear}
                    onChange={(e) =>
                      setExpiryYear(e.target.value.replace(/\D/g, "").slice(0, 2))
                    }
                    placeholder="YY"
                    maxLength={2}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    CVV
                  </label>
                  <input
                    type="text"
                    value={cvv}
                    onChange={(e) =>
                      setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))
                    }
                    placeholder="123"
                    maxLength={3}
                    className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              {errorMessage && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                  {errorMessage}
                </div>
              )}
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleSubmitPayment}
                disabled={processBankTransfer.isPending}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12"
              >
                {processBankTransfer.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Complete Payment"
                )}
              </Button>
              <Button
                onClick={() => setStep("instructions")}
                variant="outline"
                className="w-full"
              >
                Back
              </Button>
            </div>
          </Card>
        )}

        {/* Processing */}
        {step === "processing" && (
          <Card className="p-8 text-center space-y-4">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto" />
            <h1 className="text-2xl font-bold text-foreground">
              Processing Payment
            </h1>
            <p className="text-muted-foreground">
              Please wait while we process your payment...
            </p>
          </Card>
        )}

        {/* Success */}
        {step === "success" && (
          <Card className="p-8 space-y-6">
            <div className="text-center space-y-2">
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto" />
              <h1 className="text-2xl font-bold text-green-600">
                Payment Received!
              </h1>
              <p className="text-muted-foreground">
                Order #{orderNumber} has been confirmed
              </p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border border-green-200 space-y-2 text-sm">
              <p className="font-semibold text-foreground">
                What happens next?
              </p>
              <ul className="space-y-1 list-disc list-inside text-muted-foreground">
                <li>You will receive a confirmation email shortly</li>
                <li>Your order will ship within 1-2 business days</li>
                <li>Delivery takes 10-20 working days via Buffalo Logistics</li>
                <li>You'll receive tracking information via email</li>
              </ul>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => setLocation("/")}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12"
              >
                Continue Shopping
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                Order ID: {orderId}
              </p>
            </div>
          </Card>
        )}

        {/* Error */}
        {step === "error" && (
          <Card className="p-8 space-y-6">
            <div className="text-center space-y-2">
              <XCircle className="w-12 h-12 text-red-600 mx-auto" />
              <h1 className="text-2xl font-bold text-red-600">
                Payment Failed
              </h1>
              <p className="text-muted-foreground">
                {errorMessage || "Your payment could not be processed"}
              </p>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => setStep("details")}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12"
              >
                Try Again
              </Button>
              <Button
                onClick={() => setLocation("/support")}
                variant="outline"
                className="w-full"
              >
                Contact Support
              </Button>
            </div>
          </Card>
        )}

        {/* Support Info */}
        <div className="text-center text-xs text-muted-foreground">
          <p>Need help? Contact us at 066 564 7535 or support@baeby.co.za</p>
        </div>
      </div>
    </div>
  );
}
