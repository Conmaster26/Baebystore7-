import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  BarChart3,
  TrendingUp,
  Package,
  DollarSign,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { user, loading: authLoading } = useAuth();
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  // Check if user is admin
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Access Denied</h1>
          <p className="text-muted-foreground">
            You do not have permission to access the admin dashboard.
          </p>
          <Button onClick={() => setLocation("/")} className="w-full">
            Return to Home
          </Button>
        </Card>
      </div>
    );
  }

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } =
    trpc.admin.getDashboardStats.useQuery();

  // Fetch orders
  const { data: ordersData, isLoading: ordersLoading } =
    trpc.admin.getOrders.useQuery({
      page: 1,
      limit: 10,
    });

  // Fetch profit ledger
  const { data: profitData, isLoading: profitLoading } =
    trpc.admin.getProfitLedger.useQuery({
      page: 1,
      limit: 10,
    });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">
              Admin Dashboard
            </h1>
            <div className="text-sm text-muted-foreground">
              Welcome, {user?.name || "Admin"}
            </div>
          </div>
        </div>
      </div>

      <div className="container py-8 space-y-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {statsLoading ? (
            Array(4)
              .fill(0)
              .map((_, i) => (
                <Card key={i} className="p-6 animate-pulse bg-muted" />
              ))
          ) : stats ? (
            <>
              <Card className="p-6 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Total Orders
                  </span>
                  <Package className="w-5 h-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  {stats.totalOrders}
                </p>
                <p className="text-xs text-green-600">
                  {stats.completedOrders} completed
                </p>
              </Card>

              <Card className="p-6 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Total Revenue
                  </span>
                  <DollarSign className="w-5 h-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  R{stats.totalRevenue.toFixed(2)}
                </p>
                <p className="text-xs text-muted-foreground">
                  From {stats.completedOrders} orders
                </p>
              </Card>

              <Card className="p-6 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Total Profit
                  </span>
                  <TrendingUp className="w-5 h-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  R{stats.totalProfit.toFixed(2)}
                </p>
                <p className="text-xs text-green-600">
                  R{stats.transferredProfit.toFixed(2)} transferred
                </p>
              </Card>

              <Card className="p-6 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Pending Profit
                  </span>
                  <BarChart3 className="w-5 h-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">
                  R{stats.pendingProfit.toFixed(2)}
                </p>
                <p className="text-xs text-orange-600">
                  {stats.pendingOrders} pending orders
                </p>
              </Card>
            </>
          ) : null}
        </div>

        {/* Orders Table */}
        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-bold text-foreground">Recent Orders</h2>
          {ordersLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : ordersData?.orders.length ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Order #
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Customer
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Amount
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Status
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Payment
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {ordersData.orders.map((order) => (
                    <tr
                      key={order.id}
                      className="border-b border-border hover:bg-card/50 transition-colors cursor-pointer"
                      onClick={() => setSelectedOrderId(order.id)}
                    >
                      <td className="py-3 px-4 font-semibold text-foreground">
                        {order.orderNumber}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {order.customer?.firstName} {order.customer?.lastName}
                      </td>
                      <td className="py-3 px-4 font-semibold text-foreground">
                        R{parseFloat(order.totalAmount).toFixed(2)}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            order.status === "delivered"
                              ? "bg-green-100 text-green-700"
                              : order.status === "cancelled"
                                ? "bg-red-100 text-red-700"
                                : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            order.paymentStatus === "completed"
                              ? "bg-green-100 text-green-700"
                              : order.paymentStatus === "failed"
                                ? "bg-red-100 text-red-700"
                                : "bg-yellow-100 text-yellow-700"
                          }`}
                        >
                          {order.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No orders found
            </p>
          )}
        </Card>

        {/* Profit Ledger */}
        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-bold text-foreground">Profit Ledger</h2>
          {profitLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : profitData?.ledgers.length ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Order ID
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Profit Amount
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Bank Account
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Status
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {profitData.ledgers.map((ledger) => (
                    <tr
                      key={ledger.id}
                      className="border-b border-border hover:bg-card/50 transition-colors"
                    >
                      <td className="py-3 px-4 font-semibold text-foreground">
                        #{ledger.orderId}
                      </td>
                      <td className="py-3 px-4 font-semibold text-green-600">
                        R{parseFloat(ledger.profitAmount).toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {ledger.bankAccount}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            ledger.transferStatus === "completed"
                              ? "bg-green-100 text-green-700"
                              : ledger.transferStatus === "failed"
                                ? "bg-red-100 text-red-700"
                                : "bg-yellow-100 text-yellow-700"
                          }`}
                        >
                          {ledger.transferStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(ledger.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No profit entries found
            </p>
          )}
        </Card>

        {/* Info Section */}
        <Card className="p-6 bg-primary/5 border-primary/20">
          <p className="text-sm text-muted-foreground">
            <strong>Profit Account:</strong> 1996092373 | All profits are
            automatically tracked and can be transferred via the profit ledger
            above.
          </p>
        </Card>
      </div>
    </div>
  );
}
