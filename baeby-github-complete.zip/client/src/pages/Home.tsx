import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ShoppingCart, Truck, Heart, Star } from "lucide-react";
import { useState } from "react";

/**
 * Baeby Home Page - Design Philosophy: Modern Minimalism with Warmth
 * Color Palette: Soft Sage Green (#A8D5BA), Warm Cream (#FFF9F0), Rose Gold (#D4A5A5), Deep Charcoal (#2C3E50)
 * Typography: Poppins (Bold) for headers, Inter (Regular) for body, Playfair Display (Elegant) for taglines
 */

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
}

const FEATURED_PRODUCTS: Product[] = [
  {
    id: 1,
    name: "Soft Sage Onesie",
    price: 299,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Onesies",
    rating: 5,
  },
  {
    id: 2,
    name: "Cream Floral Romper",
    price: 349,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Rompers",
    rating: 5,
  },
  {
    id: 3,
    name: "Rose Gold Cardigan",
    price: 399,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Cardigans",
    rating: 5,
  },
  {
    id: 4,
    name: "Soft Pink Bodysuit",
    price: 279,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Bodysuits",
    rating: 5,
  },
  {
    id: 5,
    name: "Sage Green Sweater",
    price: 329,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Sweaters",
    rating: 5,
  },
  {
    id: 6,
    name: "Cream Lace Dress",
    price: 379,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_product_showcase-RtdMQZGHUYPJCnfJ7sexTm.webp",
    category: "Dresses",
    rating: 5,
  },
];

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [cart, setCart] = useState<Product[]>([]);
  const [showNotification, setShowNotification] = useState(false);

  const handleAddToCart = (product: Product) => {
    setCart([...cart, product]);
    setShowNotification(true);
    setTimeout(() => setShowNotification(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">B</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Baeby</h1>
          </div>
          <div className="flex items-center gap-6">
            <button className="text-foreground hover:text-primary transition-colors">Shop</button>
            <button className="text-foreground hover:text-primary transition-colors">About</button>
            <button className="text-foreground hover:text-primary transition-colors">Contact</button>
            <button className="relative">
              <ShoppingCart className="w-6 h-6 text-foreground hover:text-primary transition-colors" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-card to-background">
        <div className="container grid grid-cols-1 md:grid-cols-2 gap-12 items-center py-20">
          {/* Left: Text Content */}
          <div className="space-y-8 animate-fade-in">
            <div className="space-y-4">
              <p className="tagline text-primary text-lg">For Today, For Tomorrow</p>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Baeby is the Future of Tomorrow
              </h2>
              <p className="text-lg text-muted-foreground max-w-lg">
                Curated, premium baby clothing designed for modern families. Every piece is carefully selected to combine comfort, style, and sustainability. Welcome to the future of baby fashion.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg">
                Shop Now
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10 rounded-lg">
                Learn More
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-border">
              <div>
                <p className="text-2xl font-bold text-primary">100%</p>
                <p className="text-sm text-muted-foreground">Curated</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">5★</p>
                <p className="text-sm text-muted-foreground">Rated</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-primary">10-20d</p>
                <p className="text-sm text-muted-foreground">Delivery</p>
              </div>
            </div>
          </div>

          {/* Right: Hero Image */}
          <div className="relative h-96 md:h-full rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663626753910/TFeQHfWfW5SUbPxjd7JicG/baeby_hero_main-RtdMQZGHUYPJCnfJ7sexTm.webp"
              alt="Baeby Family"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-20 bg-card/50">
        <div className="container space-y-12">
          <div className="text-center space-y-4">
            <p className="tagline text-primary">Our Collection</p>
            <h3 className="text-4xl font-bold text-foreground">Curated for Your Little One</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Each piece in our collection is handpicked for quality, comfort, and style. From soft onesies to elegant dresses, we have everything your baby needs.
            </p>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {FEATURED_PRODUCTS.map((product) => (
              <Card
                key={product.id}
                className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 bg-background border-border"
              >
                <div className="relative h-64 overflow-hidden bg-muted">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
                    {product.category}
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div className="space-y-2">
                    <h4 className="text-lg font-bold text-foreground">{product.name}</h4>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: product.rating }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-2xl font-bold text-primary">R{product.price}</p>
                    <Button
                      size="sm"
                      className="bg-primary text-primary-foreground hover:bg-primary/90"
                      onClick={() => handleAddToCart(product)}
                    >
                      <ShoppingCart className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Baeby Section */}
      <section className="py-20 bg-background">
        <div className="container space-y-12">
          <div className="text-center space-y-4">
            <h3 className="text-4xl font-bold text-foreground">Why Choose Baeby?</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-shadow">
              <Heart className="w-12 h-12 text-primary mb-4" />
              <h4 className="text-xl font-bold text-foreground mb-3">Curated with Care</h4>
              <p className="text-muted-foreground">
                Every item is handpicked for quality, comfort, and style. We believe in curation over quantity.
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-shadow">
              <Truck className="w-12 h-12 text-primary mb-4" />
              <h4 className="text-xl font-bold text-foreground mb-3">Fast & Transparent</h4>
              <p className="text-muted-foreground">
                Delivery in 10-20 working days with full tracking. We keep you informed every step of the way.
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-shadow">
              <Star className="w-12 h-12 text-primary mb-4" />
              <h4 className="text-xl font-bold text-foreground mb-3">Premium Quality</h4>
              <p className="text-muted-foreground">
                Soft, durable, and safe for your baby. All items meet international quality standards.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Shipping & Support Section */}
      <section className="py-20 bg-card/50">
        <div className="container max-w-3xl space-y-12">
          <div className="text-center space-y-4">
            <h3 className="text-4xl font-bold text-foreground">Shipping & Support</h3>
            <p className="text-lg text-muted-foreground">
              We're committed to making your experience seamless and worry-free.
            </p>
          </div>

          <div className="space-y-6">
            <div className="p-6 bg-background rounded-lg border border-border">
              <h4 className="font-bold text-foreground mb-2">📦 Delivery Timeline</h4>
              <p className="text-muted-foreground">
                All orders are shipped within 1-2 business days. Delivery typically takes 10-20 working days to South Africa via Buffalo International Logistics.
              </p>
            </div>

            <div className="p-6 bg-background rounded-lg border border-border">
              <h4 className="font-bold text-foreground mb-2">💬 Local Support</h4>
              <p className="text-muted-foreground">
                Have questions? Contact us via WhatsApp at <strong>066 564 7535</strong> or email <strong>support@baeby.co.za</strong>. Our team is here to help!
              </p>
            </div>

            <div className="p-6 bg-background rounded-lg border border-border">
              <h4 className="font-bold text-foreground mb-2">🔄 Returns & Exchanges</h4>
              <p className="text-muted-foreground">
                Not satisfied? We offer hassle-free returns and exchanges within 30 days of purchase. Your satisfaction is our priority.
              </p>
            </div>

            <div className="p-6 bg-background rounded-lg border border-border">
              <h4 className="font-bold text-foreground mb-2">💳 Payment Methods</h4>
              <p className="text-muted-foreground">
                We accept all major payment methods including EFT, credit cards, and mobile payments. All transactions are secure and encrypted.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container text-center space-y-8">
          <h3 className="text-4xl font-bold text-primary-foreground">Ready to Discover Baeby?</h3>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto">
            Join thousands of parents who trust Baeby for premium, curated baby clothing. Start shopping today and experience the future of baby fashion.
          </p>
          <Button size="lg" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 rounded-lg">
            Shop Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-primary-foreground py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About Baeby</h4>
              <p className="text-sm text-primary-foreground/80">
                Premium, curated baby clothing for modern families. For today, for tomorrow.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-primary-foreground/80">
                <li><a href="#" className="hover:text-primary-foreground transition-colors">New Arrivals</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Best Sellers</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Collections</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-primary-foreground/80">
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Shipping Info</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-primary-foreground/80">
                <li><a href="#" className="hover:text-primary-foreground transition-colors">WhatsApp: 066 564 7535</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Email: support@baeby.co.za</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition-colors">Instagram</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm text-primary-foreground/60">
            <p>&copy; 2026 Baeby. All rights reserved. Powered by Katlego Madiba Strategic Consulting.</p>
          </div>
        </div>
      </footer>

      {/* Notification Toast */}
      {showNotification && (
        <div className="fixed bottom-4 right-4 bg-primary text-primary-foreground px-6 py-3 rounded-lg shadow-lg animate-pulse">
          ✓ Added to cart!
        </div>
      )}
    </div>
  );
}
