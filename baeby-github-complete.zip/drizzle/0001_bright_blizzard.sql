CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`lastName` varchar(100) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orderItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`productId` varchar(100) NOT NULL,
	`productName` varchar(255) NOT NULL,
	`productPrice` decimal(10,2) NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`totalPrice` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`orderNumber` varchar(50) NOT NULL,
	`status` enum('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
	`deliveryFirstName` varchar(100) NOT NULL,
	`deliveryLastName` varchar(100) NOT NULL,
	`deliveryEmail` varchar(320) NOT NULL,
	`deliveryPhone` varchar(20) NOT NULL,
	`deliveryAddress` text NOT NULL,
	`deliveryCity` varchar(100) NOT NULL,
	`deliveryProvince` varchar(100) NOT NULL,
	`deliveryPostalCode` varchar(20) NOT NULL,
	`subtotal` decimal(10,2) NOT NULL,
	`profitMargin` decimal(10,2) NOT NULL,
	`shippingCost` decimal(10,2) DEFAULT '0',
	`tax` decimal(10,2) DEFAULT '0',
	`totalAmount` decimal(10,2) NOT NULL,
	`paymentMethod` varchar(50) NOT NULL,
	`paymentStatus` enum('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
	`paymentReference` varchar(100),
	`supplierOrderId` varchar(100),
	`supplierName` varchar(50),
	`profitTransferred` int DEFAULT 0,
	`profitTransferDate` timestamp,
	`profitTransferReference` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderNumber_unique` UNIQUE(`orderNumber`)
);
--> statement-breakpoint
CREATE TABLE `profitLedger` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`profitAmount` decimal(10,2) NOT NULL,
	`bankAccount` varchar(50) NOT NULL,
	`transferStatus` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
	`transferDate` timestamp,
	`transferReference` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profitLedger_id` PRIMARY KEY(`id`)
);
