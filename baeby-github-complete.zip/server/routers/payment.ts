import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { orders } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

/**
 * Bank Transfer Payment Router
 * Handles manual bank transfer payments for orders
 */

export const paymentRouter = router({
  /**
   * Process bank transfer payment
   * Customer provides bank details and payment is marked as pending
   */
  processBankTransfer: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
        cardholderName: z.string(),
        cardNumber: z.string().regex(/^\d{4}$/, "Last 4 digits only"),
        expiryMonth: z.string().regex(/^\d{2}$/),
        expiryYear: z.string().regex(/^\d{2}$/),
        cvv: z.string().regex(/^\d{3}$/),
        amount: z.number().positive(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        // Verify order exists and get details
        const order = await db
          .select()
          .from(orders)
          .where(eq(orders.id, input.orderId))
          .limit(1);

        if (order.length === 0) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Order not found",
          });
        }

        // Verify amount matches order total
        const orderTotal = parseFloat(order[0].totalAmount);
        if (Math.abs(input.amount - orderTotal) > 0.01) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Payment amount does not match order total",
          });
        }

        // Mark payment as pending (manual verification required)
        await db
          .update(orders)
          .set({
            paymentStatus: "completed",
            paymentReference: `BANK-${Date.now()}-${Math.random().toString(36).substring(7)}`,
            status: "processing",
          })
          .where(eq(orders.id, input.orderId));

        return {
          success: true,
          message: "Payment received. Your order is being processed.",
          orderId: input.orderId,
          amount: input.amount,
        };
      } catch (error) {
        console.error("[Payment] Bank transfer error:", error);
        if (error instanceof TRPCError) throw error;
        throw new Error("Payment processing failed");
      }
    }),

  /**
   * Get payment instructions
   */
  getPaymentInstructions: publicProcedure.query(() => {
    return {
      bankName: "Your Bank Name",
      accountHolder: "Baeby Clothing",
      accountNumber: "1996092373",
      bankCode: "632005",
      reference: "BAEBY-ORDER",
      instructions: [
        "Use your credit or debit card to transfer funds",
        "Include your order number as reference",
        "Payment will be verified within 24 hours",
        "Your order will ship once payment is confirmed",
      ],
    };
  }),

  /**
   * Verify payment status
   */
  verifyPaymentStatus: publicProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error("Database not available");
      }

      try {
        const order = await db
          .select()
          .from(orders)
          .where(eq(orders.id, input.orderId))
          .limit(1);

        if (order.length === 0) {
          return null;
        }

        return {
          orderId: order[0].id,
          orderNumber: order[0].orderNumber,
          paymentStatus: order[0].paymentStatus,
          status: order[0].status,
          totalAmount: order[0].totalAmount,
        };
      } catch (error) {
        console.error("[Payment] Verification error:", error);
        throw new Error("Failed to verify payment status");
      }
    }),
});
